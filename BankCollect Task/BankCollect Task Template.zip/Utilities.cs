﻿using NHibernate;
using Parkway.Scheduler.Configuration;
using Parkway.Tools.NHibernate;
using Quartz;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace $safeprojectname$
{
    public class Utilities : JobDataProvider
    {
        public Utilities(JobExecutionContext context) : base(context) { }

        public string NHibernateSessionFactory
        {
            get
            {
                var x = GetConfig("NHibernateSessionFactory");
                return x;
            }
        }

        public ISession CurrentSession
        {
            get
            {
                Logger.Info("About to get NHibernateSessionFactory value from config");
                Logger.InfoFormat("NHibernateSessionFactory: {0}", NHibernateSessionFactory);
                SessionManager sessionMgr = SessionManager.GetInstance(NHibernateSessionFactory);
                return sessionMgr == null ? null : sessionMgr.GetSession();
            }
        }

        public log4net.ILog DefaultLogger
        {
            get
            {
                return log4net.LogManager.GetLogger("");
            }
        }
    }
}
