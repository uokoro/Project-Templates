﻿using log4net;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace $safeprojectname$._Task_Name_
{

    /// <summary>
    /// Th
    /// </summary>
    public class TaskImpl
    {
        private ILog Logger;
        private Utilities taskUtil;

        public TaskImpl(Utilities taskUtil)
        {
            this.taskUtil = taskUtil;
            Logger = taskUtil.Logger;
        }

        /// <summary>
        /// 
        /// </summary>
        public void Process()
        {

        }
    }
}
