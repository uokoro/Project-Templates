﻿using Quartz;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace $safeprojectname$._Task_Name_
{

    /// <summary>
    /// 
    /// </summary>
    public class TaskEntry : IStatefulJob
    {
        #region IJob Members
        private log4net.ILog Logger;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="context"></param>
        public void Execute(JobExecutionContext context)
        {
            try
            {
                Utilities taskUtil = new Utilities(context);
                Logger = taskUtil.Logger;
                var taskImpl = new TaskImpl(taskUtil);

                taskImpl.Process();

            }
            catch (Exception ex)
            {
                if (Logger == null)
                    Logger = log4net.LogManager.GetLogger(context.JobDetail.Name.Replace(' ', '_'));
                Logger.Error(ex.Message, ex);
            }
        }


        #endregion

    }
}
